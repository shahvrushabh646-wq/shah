import React, { useEffect, useMemo, useState } from 'react';
import {
  BookOpen,
  Brain,
  CheckCircle2,
  ChevronRight,
  ClipboardList,
  LayoutDashboard,
  Menu,
  Target,
  X,
  Zap,
} from 'lucide-react';
import {
  CMAT_SYLLABUS_TOPICS,
  DAILY_TIMETABLE,
  INITIAL_ERROR_LOG,
  INITIAL_QUIZ_ATTEMPTS,
  INITIAL_TOPIC_PROGRESS,
  INITIAL_USER_PROFILE,
} from './data/cmatCurriculum';
import { QUIZ_BANK } from './data/questionBank';
import {
  computeDailyProgressCard,
  computeSectionAnalytics,
  formatTopicStatusLabel,
} from './lib/progressCalculator';
import type {
  QuizAttemptRecord,
  QuizSet,
  SubjectKey,
  SyllabusTopic,
  TopicProgressRecord,
  TopicStatus,
  UserLearningProfile,
} from './types/mitra';

type Tab = 'dashboard' | 'plan' | 'practice';

const STORAGE_KEY = 'mitra-cmat-v2-state';

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as {
      profile: UserLearningProfile;
      topicProgress: TopicProgressRecord[];
      quizAttempts: QuizAttemptRecord[];
    };
  } catch {
    return null;
  }
}

function saveState(data: {
  profile: UserLearningProfile;
  topicProgress: TopicProgressRecord[];
  quizAttempts: QuizAttemptRecord[];
}) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

export default function App() {
  const saved = loadState();
  const [tab, setTab] = useState<Tab>('dashboard');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profile, setProfile] = useState<UserLearningProfile>(
    saved?.profile || INITIAL_USER_PROFILE
  );
  const [topicProgress, setTopicProgress] = useState<TopicProgressRecord[]>(
    saved?.topicProgress || INITIAL_TOPIC_PROGRESS
  );
  const [quizAttempts, setQuizAttempts] = useState<QuizAttemptRecord[]>(
    saved?.quizAttempts || INITIAL_QUIZ_ATTEMPTS
  );
  const [activeQuiz, setActiveQuiz] = useState<QuizSet | null>(null);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [planFilter, setPlanFilter] = useState<'All' | SubjectKey>('All');

  useEffect(() => {
    saveState({ profile, topicProgress, quizAttempts });
  }, [profile, topicProgress, quizAttempts]);

  const dayCard = useMemo(
    () =>
      computeDailyProgressCard({
        dayNumber: profile.currentDay || 1,
        profile,
        topicProgress,
        quizAttempts,
        errorLog: INITIAL_ERROR_LOG,
      }),
    [profile, topicProgress, quizAttempts]
  );

  const sections = useMemo(
    () =>
      computeSectionAnalytics({
        topicProgress,
        quizAttempts,
        errorLog: INITIAL_ERROR_LOG,
      }),
    [topicProgress, quizAttempts]
  );

  const progressMap = useMemo(
    () => new Map(topicProgress.map((t) => [t.topicId, t])),
    [topicProgress]
  );

  function markTopic(topic: SyllabusTopic, status: TopicStatus) {
    setTopicProgress((prev) => {
      const idx = prev.findIndex((p) => p.topicId === topic.id);
      const now = new Date().toISOString();
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = { ...next[idx], status, updatedAt: now };
        return next;
      }
      return [
        ...prev,
        {
          topicId: topic.id,
          subject: topic.subject,
          status,
          bestScore: 0,
          totalQuestions: 0,
          attemptsCount: 0,
          timeSpentMinutes: topic.estimatedMinutes || 20,
          createdAt: now,
          updatedAt: now,
        },
      ];
    });
    setProfile((p) => ({
      ...p,
      currentTopicId: topic.id,
      currentSubject: topic.subject,
      updatedAt: new Date().toISOString(),
    }));
  }

  function startQuiz(quiz: QuizSet) {
    setActiveQuiz(quiz);
    setAnswers({});
    setQuizSubmitted(false);
    setTab('practice');
  }

  function submitQuiz() {
    if (!activeQuiz) return;
    let score = 0;
    for (const q of activeQuiz.questions) {
      if (q.type === 'mcq' && answers[q.id] === q.correctOptionIndex) score += 1;
    }
    const total = activeQuiz.questions.length;
    const accuracy = total ? Math.round((score / total) * 100) : 0;
    const passed = accuracy >= (activeQuiz.passingPercent || 50);
    const now = new Date().toISOString();

    const attempt: QuizAttemptRecord = {
      id: `att_${Date.now()}`,
      quizId: activeQuiz.id,
      title: activeQuiz.title,
      subject: activeQuiz.subject,
      topicId: activeQuiz.topicId,
      examFormat: activeQuiz.examFormat,
      score,
      total,
      accuracyPercent: accuracy,
      durationSeconds: 0,
      passed,
      status: 'completed',
      createdAt: now,
    };
    setQuizAttempts((prev) => [attempt, ...prev]);

    setTopicProgress((prev) => {
      const idx = prev.findIndex((p) => p.topicId === activeQuiz.topicId);
      const status: TopicStatus = passed ? 'quiz_passed' : 'quiz_attempted';
      if (idx >= 0) {
        const next = [...prev];
        const cur = next[idx];
        next[idx] = {
          ...cur,
          status: cur.status === 'mastered' ? 'mastered' : status,
          bestScore: Math.max(cur.bestScore, score),
          totalQuestions: total,
          attemptsCount: cur.attemptsCount + 1,
          updatedAt: now,
        };
        return next;
      }
      return [
        ...prev,
        {
          topicId: activeQuiz.topicId,
          subject: activeQuiz.subject,
          status,
          bestScore: score,
          totalQuestions: total,
          attemptsCount: 1,
          timeSpentMinutes: activeQuiz.timeLimitMinutes || 15,
          createdAt: now,
          updatedAt: now,
        },
      ];
    });
    setQuizSubmitted(true);
  }

  const nav = [
    { id: 'dashboard' as Tab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'plan' as Tab, label: 'Study Plan', icon: BookOpen },
    { id: 'practice' as Tab, label: 'Practice', icon: ClipboardList },
  ];

  const filteredTopics = CMAT_SYLLABUS_TOPICS.filter(
    (t) => planFilter === 'All' || t.subject === planFilter
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Top bar */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-600 text-white">
              <Brain className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-bold tracking-tight">Mitra AI Tutor</div>
              <div className="text-[11px] text-slate-500">CMAT 2026 · Day {profile.currentDay}</div>
            </div>
          </div>
          <nav className="hidden items-center gap-1 md:flex">
            {nav.map((n) => (
              <button
                key={n.id}
                type="button"
                onClick={() => setTab(n.id)}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium transition ${
                  tab === n.id
                    ? 'bg-sky-50 text-sky-700'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <n.icon className="h-4 w-4" />
                {n.label}
              </button>
            ))}
          </nav>
          <button
            type="button"
            className="md:hidden rounded-lg p-2 text-slate-600 hover:bg-slate-100"
            onClick={() => setMobileOpen((v) => !v)}
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
        {mobileOpen && (
          <div className="border-t border-slate-100 px-4 py-2 md:hidden">
            {nav.map((n) => (
              <button
                key={n.id}
                type="button"
                onClick={() => {
                  setTab(n.id);
                  setMobileOpen(false);
                }}
                className={`flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium ${
                  tab === n.id ? 'bg-sky-50 text-sky-700' : 'text-slate-700'
                }`}
              >
                <n.icon className="h-4 w-4" />
                {n.label}
              </button>
            ))}
          </div>
        )}
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8">
        {/* DASHBOARD */}
        {tab === 'dashboard' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
              <p className="mt-1 text-sm text-slate-600">
                Your CMAT sprint progress · Day {profile.currentDay} of 8
              </p>
            </div>

            {/* KPI row */}
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Kpi
                label="Study minutes"
                value={`${profile.totalStudyMinutes || 0}m`}
                hint="lifetime tracked"
              />
              <Kpi
                label="Topics tracked"
                value={String(topicProgress.length)}
                hint={`${topicProgress.filter((t) => t.status === 'mastered' || t.status === 'quiz_passed').length} passed`}
              />
              <Kpi
                label="Quizzes taken"
                value={String(quizAttempts.length)}
                hint={`${quizAttempts.filter((q) => q.passed).length} passed`}
              />
              <Kpi
                label="Day accuracy"
                value={`${dayCard.overallAccuracy || 0}%`}
                hint="from recent attempts"
              />
            </div>

            {/* Today card */}
            <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 className="text-lg font-semibold">{dayCard.dateLabel}</h2>
                  <p className="mt-1 text-sm text-slate-600">
                    Target {dayCard.targetMinutes} min · Studied {dayCard.minutesStudied} min
                  </p>
                </div>
                <span className="inline-flex items-center gap-1 rounded-full bg-sky-50 px-3 py-1 text-xs font-medium text-sky-700">
                  <Zap className="h-3.5 w-3.5" />
                  Active sprint
                </span>
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {dayCard.subjects.map((s) => (
                  <div
                    key={s.subject}
                    className={`rounded-xl border p-4 ${
                      s.completed
                        ? 'border-emerald-200 bg-emerald-50/50'
                        : s.pendingAssessment
                          ? 'border-amber-200 bg-amber-50/40'
                          : 'border-slate-200 bg-slate-50/50'
                    }`}
                  >
                    <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                      {s.subject}
                    </div>
                    <div className="mt-1 text-sm font-medium text-slate-900">{s.statusLabel}</div>
                    <div className="mt-1 text-xs text-slate-600">{s.detail}</div>
                  </div>
                ))}
              </div>

              {dayCard.nextRecommendedAction && (
                <div className="mt-5 flex flex-col gap-3 rounded-xl border border-sky-200 bg-sky-50/60 p-4 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wide text-sky-700">
                      Next recommended
                    </div>
                    <div className="mt-0.5 font-medium text-slate-900">
                      {dayCard.nextRecommendedAction.label}
                    </div>
                    {dayCard.nextRecommendedAction.reason && (
                      <div className="mt-0.5 text-sm text-slate-600">
                        {dayCard.nextRecommendedAction.reason}
                      </div>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const q = QUIZ_BANK.find(
                        (x) =>
                          x.topicId === dayCard.nextRecommendedAction.topicId ||
                          x.id === dayCard.nextRecommendedAction.quizId
                      );
                      if (q) startQuiz(q);
                      else setTab('plan');
                    }}
                    className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-lg bg-sky-600 px-4 py-2 text-sm font-semibold text-white hover:bg-sky-700"
                  >
                    Continue
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              )}
            </section>

            {/* Section mastery */}
            <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
              <h2 className="text-lg font-semibold">Section mastery</h2>
              <div className="mt-4 space-y-4">
                {sections.map((s) => (
                  <div key={s.subject}>
                    <div className="mb-1.5 flex items-center justify-between text-sm">
                      <span className="font-medium text-slate-800">{s.subject}</span>
                      <span className="tabular-nums text-slate-500">
                        {s.masteredTopics}/{s.totalTopics} · {s.masteryPercent}%
                      </span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                      <div
                        className="h-full rounded-full bg-sky-500 transition-all"
                        style={{ width: `${s.masteryPercent}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Recent quizzes */}
            <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold">Recent quiz attempts</h2>
                <button
                  type="button"
                  onClick={() => setTab('practice')}
                  className="text-sm font-medium text-sky-600 hover:text-sky-700"
                >
                  Practice →
                </button>
              </div>
              {quizAttempts.length === 0 ? (
                <p className="mt-3 text-sm text-slate-500">No attempts yet. Start a topic quiz.</p>
              ) : (
                <ul className="mt-3 divide-y divide-slate-100">
                  {quizAttempts.slice(0, 5).map((a) => (
                    <li key={a.id} className="flex items-center justify-between py-3 text-sm">
                      <div>
                        <div className="font-medium text-slate-900">{a.title}</div>
                        <div className="text-xs text-slate-500">{a.subject}</div>
                      </div>
                      <div
                        className={`font-semibold tabular-nums ${
                          a.passed ? 'text-emerald-600' : 'text-amber-600'
                        }`}
                      >
                        {a.score}/{a.total} ({a.accuracyPercent}%)
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </div>
        )}

        {/* STUDY PLAN */}
        {tab === 'plan' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Study Plan</h1>
              <p className="mt-1 text-sm text-slate-600">
                8-day CMAT sprint · {CMAT_SYLLABUS_TOPICS.length} modules
              </p>
            </div>

            {/* Daily timetable */}
            <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
              <div className="border-b border-slate-100 px-5 py-3">
                <h2 className="font-semibold">Daily 2-hour timetable</h2>
              </div>
              <div className="divide-y divide-slate-50">
                {DAILY_TIMETABLE.map((slot) => (
                  <div
                    key={slot.subject}
                    className="flex items-center justify-between gap-4 px-5 py-3 text-sm"
                  >
                    <div>
                      <div className="font-medium text-slate-900">
                        {slot.alternateSubject
                          ? `${slot.subject} / ${slot.alternateSubject}`
                          : slot.subject}
                      </div>
                      <div className="text-xs text-slate-500">{slot.activity}</div>
                    </div>
                    <div className="shrink-0 font-mono text-xs font-semibold text-slate-600">
                      {slot.minutes} min
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Filters */}
            <div className="flex flex-wrap gap-2">
              {(
                [
                  'All',
                  'Quantitative Techniques',
                  'Logical Reasoning',
                  'Language Comprehension',
                  'General Knowledge',
                  'Innovation & Entrepreneurship',
                ] as const
              ).map((f) => (
                <button
                  key={f}
                  type="button"
                  onClick={() => setPlanFilter(f)}
                  className={`rounded-full px-3 py-1 text-xs font-medium ${
                    planFilter === f
                      ? 'bg-sky-600 text-white'
                      : 'bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {f === 'All' ? 'All subjects' : f}
                </button>
              ))}
            </div>

            {/* Topics */}
            <div className="space-y-3">
              {filteredTopics.map((topic) => {
                const prog = progressMap.get(topic.id);
                const status = prog?.status || 'not_started';
                const quiz = QUIZ_BANK.find((q) => q.id === topic.linkedQuizId || q.topicId === topic.id);
                return (
                  <article
                    key={topic.id}
                    className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-5"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                          <span className="font-mono">Day {topic.dayNumber}</span>
                          <span>·</span>
                          <span>{topic.subject}</span>
                          <span>·</span>
                          <span>{topic.estimatedMinutes} min</span>
                        </div>
                        <h3 className="mt-1 text-base font-semibold text-slate-900">{topic.title}</h3>
                        <p className="mt-1 text-sm text-slate-600">{topic.summary}</p>
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          {topic.keyConcepts.slice(0, 4).map((c) => (
                            <span
                              key={c}
                              className="rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-600"
                            >
                              {c}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="flex shrink-0 flex-col items-end gap-2">
                        <StatusBadge status={status} />
                        <div className="flex flex-wrap gap-2">
                          {status === 'not_started' && (
                            <button
                              type="button"
                              onClick={() => markTopic(topic, 'viewed')}
                              className="rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-semibold text-white hover:bg-slate-800"
                            >
                              Mark viewed
                            </button>
                          )}
                          {quiz && (
                            <button
                              type="button"
                              onClick={() => startQuiz(quiz)}
                              className="rounded-lg bg-sky-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-sky-700"
                            >
                              Take quiz
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        )}

        {/* PRACTICE */}
        {tab === 'practice' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Practice</h1>
              <p className="mt-1 text-sm text-slate-600">
                Topic drills · sectional tests · full mock
              </p>
            </div>

            {activeQuiz ? (
              <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-semibold">{activeQuiz.title}</h2>
                    <p className="text-sm text-slate-500">
                      {activeQuiz.subtitle} · {activeQuiz.questions.length} questions ·{' '}
                      {activeQuiz.timeLimitMinutes} min
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveQuiz(null);
                      setQuizSubmitted(false);
                      setAnswers({});
                    }}
                    className="text-sm font-medium text-slate-500 hover:text-slate-800"
                  >
                    ← Back to list
                  </button>
                </div>

                <div className="mt-6 space-y-6">
                  {activeQuiz.questions.map((q, qi) => (
                    <div key={q.id} className="rounded-xl border border-slate-100 bg-slate-50/50 p-4">
                      <div className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                        Q{qi + 1}
                      </div>
                      <p className="mt-1 font-medium text-slate-900">{q.questionText}</p>
                      {q.options && (
                        <div className="mt-3 space-y-2">
                          {q.options.map((opt, oi) => {
                            const selected = answers[q.id] === oi;
                            const correct = quizSubmitted && q.correctOptionIndex === oi;
                            const wrong = quizSubmitted && selected && !correct;
                            return (
                              <button
                                key={oi}
                                type="button"
                                disabled={quizSubmitted}
                                onClick={() => setAnswers((a) => ({ ...a, [q.id]: oi }))}
                                className={`flex w-full items-start gap-3 rounded-lg border px-3 py-2.5 text-left text-sm transition ${
                                  correct
                                    ? 'border-emerald-300 bg-emerald-50'
                                    : wrong
                                      ? 'border-rose-300 bg-rose-50'
                                      : selected
                                        ? 'border-sky-400 bg-sky-50'
                                        : 'border-slate-200 bg-white hover:border-slate-300'
                                }`}
                              >
                                <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-current text-[11px] font-bold opacity-70">
                                  {String.fromCharCode(65 + oi)}
                                </span>
                                <span>{opt}</span>
                              </button>
                            );
                          })}
                        </div>
                      )}
                      {quizSubmitted && (
                        <div className="mt-3 rounded-lg bg-white p-3 text-sm text-slate-600 ring-1 ring-slate-100">
                          <span className="font-medium text-slate-800">Explanation: </span>
                          {q.explanation}
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {!quizSubmitted ? (
                  <button
                    type="button"
                    onClick={submitQuiz}
                    className="mt-6 w-full rounded-xl bg-sky-600 py-3 text-sm font-semibold text-white hover:bg-sky-700 sm:w-auto sm:px-8"
                  >
                    Submit answers
                  </button>
                ) : (
                  <div className="mt-6 flex flex-wrap items-center gap-4 rounded-xl border border-slate-200 bg-slate-50 p-4">
                    <CheckCircle2 className="h-6 w-6 text-emerald-600" />
                    <div>
                      <div className="font-semibold text-slate-900">Quiz submitted</div>
                      <div className="text-sm text-slate-600">
                        Score saved to your dashboard. Review explanations above.
                      </div>
                    </div>
                  </div>
                )}
              </section>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2">
                {QUIZ_BANK.map((quiz) => {
                  const past = quizAttempts.filter((a) => a.quizId === quiz.id);
                  const best = past.reduce((m, a) => Math.max(m, a.accuracyPercent), 0);
                  return (
                    <button
                      key={quiz.id}
                      type="button"
                      onClick={() => startQuiz(quiz)}
                      className="rounded-2xl border border-slate-200 bg-white p-5 text-left transition hover:border-sky-300 hover:shadow-sm"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="text-xs font-semibold uppercase tracking-wide text-sky-600">
                            {quiz.examFormat?.replace('_', ' ') || 'topic quiz'}
                          </div>
                          <h3 className="mt-1 font-semibold text-slate-900">{quiz.title}</h3>
                          <p className="mt-1 text-sm text-slate-500">{quiz.subtitle}</p>
                        </div>
                        <Target className="h-5 w-5 shrink-0 text-slate-300" />
                      </div>
                      <div className="mt-4 flex flex-wrap gap-2 text-xs text-slate-500">
                        <span className="rounded-md bg-slate-100 px-2 py-0.5">
                          {quiz.questions.length} Qs
                        </span>
                        <span className="rounded-md bg-slate-100 px-2 py-0.5">
                          {quiz.timeLimitMinutes} min
                        </span>
                        <span className="rounded-md bg-slate-100 px-2 py-0.5">{quiz.subject}</span>
                        {past.length > 0 && (
                          <span className="rounded-md bg-emerald-50 px-2 py-0.5 text-emerald-700">
                            Best {best}%
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>

      <footer className="border-t border-slate-200 py-6 text-center text-xs text-slate-400">
        Mitra AI Tutor · CMAT 2026 · Progress saved in this browser
      </footer>
    </div>
  );
}

function Kpi({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4">
      <div className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</div>
      <div className="mt-1 text-2xl font-bold tabular-nums tracking-tight text-slate-900">{value}</div>
      <div className="mt-0.5 text-xs text-slate-500">{hint}</div>
    </div>
  );
}

function StatusBadge({ status }: { status: TopicStatus | string }) {
  const label = formatTopicStatusLabel(status as TopicProgressRecord['status']);
  const color =
    status === 'mastered' || status === 'quiz_passed'
      ? 'bg-emerald-50 text-emerald-700 ring-emerald-200'
      : status === 'viewed' || status === 'quiz_attempted'
        ? 'bg-amber-50 text-amber-700 ring-amber-200'
        : 'bg-slate-100 text-slate-600 ring-slate-200';
  return (
    <span className={`inline-flex rounded-full px-2.5 py-0.5 text-[11px] font-semibold ring-1 ${color}`}>
      {label}
    </span>
  );
}
